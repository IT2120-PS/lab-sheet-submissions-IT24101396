getwd()
setwd("C:\Users\Sasini\OneDrive - Sri Lanka Institute of Information Technology\Desktop\IT24101396 Lab 04")
#Lab Sheet 04
#Exercise
#1)
branch_data <- read.csv("Exercise.txt", header = TRUE)
head(branch_data)
#3)
boxplot(branch_data$Sales,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue")
#4)
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)
#5)
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower <- q1 - 1.5*iqr
  upper <- q3 + 1.5*iqr
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

find_outliers(branch_data$Years_X3)
